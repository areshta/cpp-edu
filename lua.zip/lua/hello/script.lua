function print_str(str)
    print(str)
end
print ("Hello World")
LuaOutputToCpp("Call cpp-fun")
print_str("print_str from Lua")
